﻿using System;

[Serializable]
public enum UserReportingPlatformType
{
    Default,

    Async
}