﻿namespace Unity.Cloud.Authorization
{
    public enum LicenseLevel
    {
        None = 0,

        Personal = 10,

        Plus = 20,

        Pro = 30,
    }
}