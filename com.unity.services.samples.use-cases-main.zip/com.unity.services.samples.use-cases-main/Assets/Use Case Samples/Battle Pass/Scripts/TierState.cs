namespace UnityGamingServicesUseCases
{
    namespace BattlePass
    {
        public enum TierState : int
        {
            Locked,
            Unlocked,
            Claimed,
        }
    }
}
