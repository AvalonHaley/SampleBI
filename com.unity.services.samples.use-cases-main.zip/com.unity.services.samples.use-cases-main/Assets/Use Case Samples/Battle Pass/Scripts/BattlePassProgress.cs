namespace UnityGamingServicesUseCases
{
    namespace BattlePass
    {
        public class BattlePassProgress
        {
            public int seasonXP;
            public bool ownsBattlePass;
            public TierState[] tierStates;
        }
    }
}
